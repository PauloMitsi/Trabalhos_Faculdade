Aluno: Paulo Cesar de Oliveira Mitsi
Ra: 2410362